# Santa Inc.

[![](https://img.shields.io/github/release-pre/ParkSB/santa-inc.svg?style=flat-square)](https://github.com/ParkSB/santa-inc/releases)
[![](https://img.shields.io/github/license/ParkSB/santa-inc.svg?style=flat-square)](https://github.com/ParkSB/santa-inc/blob/develop/LICENSE)

> **_세계를 선도하는 글로벌 기업 (주)산타_**

Santa Inc.는 루돌프와 요정을 착취하는 clicker 게임입니다. 초국적 블랙 기업 산타 주식회사를 운영해보세요! 
 
# [🎮 PLAY (Web)](https://parksb.github.io/santa-inc/)

![Santa Inc.](assets/meta/preview.png)

그렇습니다. 크리스마스에는 역시 코딩이죠.

2015년 12월 24일 ~~무리하게 크리스마스 이브에 맞춰 런칭하려다가 엉망이 된~~ 완성된 코드는 [GitLab - Santa Inc. v1.0.1](https://gitlab.com/ParkSB/santa-inc)에 있습니다. 2015년 1.0.1 버전은 [harooo.com/oddgame/santa](https://harooo.com/oddgame/santa/)에서 플레이할 수 있습니다.